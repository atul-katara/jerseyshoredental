<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link https://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'addisiondental');

/** MySQL database username */
define('DB_USER', 'addisiondental');

/** MySQL database password */
define('DB_PASSWORD', 'd0W@mZEZ');

/** MySQL hostname */
define('DB_HOST', 'addisiondental.db.9269272.hostedresource.com');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '>QNFS2)9p2+ZE21-9Nl!gi1vGE+G}LIG2*V#Y:2/We/AsY*zj8:Eht2F:dkVxk34');
define('SECURE_AUTH_KEY',  'Zyx/vRE%<H*A[DT$X{tkB<q(Ft`<Lvys?yD!Ijl7ja(T5CY5Rt>^N+rshwCt{KTH');
define('LOGGED_IN_KEY',    '^sN*7+O^Cab-Sr{ai5|$@/Fq{q`?+0e% *u+^Fj96[&E$glvN%xa?e3)!NS:t:<F');
define('NONCE_KEY',        'R0=w=*4>h-SRk=I!A&qCWlkLRDKj*.r}w[KiYa17xOxI,*Rxyu^UPyO{c$?,=lX%');
define('AUTH_SALT',        'G14%E,l-+UJb(Tr4mc<y;xmp0885]z:ex}GA=?+|Dp_2}2.,T 89:vs-H#o|iwfs');
define('SECURE_AUTH_SALT', 'n_F]E:*b,_>Ejk{Agn6LKR,qE=|!L==|X;z+X{N@M4;t?m(SoN*{uW$|R0 c;;Q9');
define('LOGGED_IN_SALT',   'ql-(45SK6SB!O0HA_* W,[>X$a^F8Z,)m)X.7CBs`Fnhr0e8Kt`uz)+U+QM&q]@j');
define('NONCE_SALT',       's)@*Z-`Q QAxjg-Yea;!b!m-ef!-asl+Lgk$*[ztmH(x|vp]e2y5^::y{l@c2K(D');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
